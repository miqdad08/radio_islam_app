//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<flutter_radio_player/FlutterRadioPlayerPlugin.h>)
#import <flutter_radio_player/FlutterRadioPlayerPlugin.h>
#else
@import flutter_radio_player;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [FlutterRadioPlayerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterRadioPlayerPlugin"]];
}

@end
